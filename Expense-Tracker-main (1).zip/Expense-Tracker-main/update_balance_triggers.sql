-- Trigger to update balance when expense is added
DELIMITER //
CREATE TRIGGER update_balance_after_expense
AFTER INSERT ON expenses
FOR EACH ROW
BEGIN
    UPDATE users 
    SET balance = balance - NEW.expense 
    WHERE user_id = NEW.user_id;
END//
DELIMITER ;

-- Trigger to update balance when expense is deleted
DELIMITER //
CREATE TRIGGER update_balance_after_expense_delete
AFTER DELETE ON expenses
FOR EACH ROW
BEGIN
    UPDATE users 
    SET balance = balance + OLD.expense 
    WHERE user_id = OLD.user_id;
END//
DELIMITER ;
