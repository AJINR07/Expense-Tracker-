<?php
include("session.php");
$success_msg = '';
$error_msg = '';

if (isset($_POST['change_password'])) {
    $current_pass = md5($_POST['current_password']);
    $new_pass = $_POST['new_password'];
    $confirm_pass = $_POST['confirm_password'];
    $check = mysqli_query($con, "SELECT password FROM users WHERE user_id = '$userid'");
    $row = mysqli_fetch_assoc($check);
    if ($row['password'] == $current_pass) {
        if ($new_pass == $confirm_pass && strlen($new_pass) >= 6) {
            mysqli_query($con, "UPDATE users SET password = '".md5($new_pass)."' WHERE user_id = '$userid'");
            $success_msg = "Password changed!";
        } else { $error_msg = "Passwords don't match or too short."; }
    } else { $error_msg = "Current password incorrect."; }
}

$profile_img = getProfileImage($profile_path);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Settings</title>
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <script src="js/feather.min.js"></script>
</head>
<body>
<div class="d-flex" id="wrapper">
    <div class="border-right" id="sidebar-wrapper">
        <div class="user">
            <img class="img img-fluid rounded-circle" src="<?php echo $profile_img; ?>" width="100" height="100">
            <h5><?php echo $username; ?></h5>
            <p><?php echo $useremail; ?></p>
            <span class="balance-display">₹<?php echo number_format($userbalance, 2); ?></span>
        </div>
        <div class="sidebar-heading">Management</div>
        <div class="list-group list-group-flush">
            <a href="index.php" class="list-group-item list-group-item-action"><span data-feather="home"></span> Dashboard</a>
            <a href="add_income.php" class="list-group-item list-group-item-action"><span data-feather="plus-circle"></span> Add Income</a>
            <a href="manage_income.php" class="list-group-item list-group-item-action"><span data-feather="trending-up"></span> Manage Income</a>
            <a href="add_expense.php" class="list-group-item list-group-item-action"><span data-feather="minus-circle"></span> Add Expenses</a>
            <a href="manage_expense.php" class="list-group-item list-group-item-action"><span data-feather="credit-card"></span> Manage Expenses</a>
            <a href="expensereport.php" class="list-group-item list-group-item-action"><span data-feather="file-text"></span> Reports</a>
        </div>
        <div class="sidebar-heading">Settings</div>
        <div class="list-group list-group-flush">
            <a href="profile.php" class="list-group-item list-group-item-action"><span data-feather="user"></span> Profile</a>
            <a href="settings.php" class="list-group-item list-group-item-action sidebar-active"><span data-feather="settings"></span> Settings</a>
            <a href="logout.php" class="list-group-item list-group-item-action"><span data-feather="log-out"></span> Logout</a>
        </div>
    </div>
    <div id="page-content-wrapper">
        <nav class="navbar navbar-expand-lg navbar-light border-bottom">
            <button class="toggler" type="button" id="menu-toggle"><span data-feather="menu"></span></button>
            <div class="col-md-11 text-center"><h3 class="try">Settings</h3></div>
        </nav>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-md-6 mt-4">
                    <?php if ($success_msg): ?><div class="alert alert-success"><?php echo $success_msg; ?></div><?php endif; ?>
                    <?php if ($error_msg): ?><div class="alert alert-danger"><?php echo $error_msg; ?></div><?php endif; ?>
                    <div class="card">
                        <div class="card-body">
                            <h5>Change Password</h5>
                            <form method="POST">
                                <div class="form-group"><label>Current Password</label><input type="password" class="form-control" name="current_password" required></div>
                                <div class="form-group"><label>New Password</label><input type="password" class="form-control" name="new_password" minlength="6" required></div>
                                <div class="form-group"><label>Confirm Password</label><input type="password" class="form-control" name="confirm_password" minlength="6" required></div>
                                <button type="submit" name="change_password" class="btn btn-primary">Update Password</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery.slim.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script>feather.replace();$("#menu-toggle").click(function(e){e.preventDefault();$("#wrapper").toggleClass("toggled");});</script>
</body>
</html>
