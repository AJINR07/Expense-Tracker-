-- Table structure for table `income`
CREATE TABLE IF NOT EXISTS `income` (
  `income_id` int(20) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(15) NOT NULL,
  `amount` DECIMAL(12,2) NOT NULL,
  `incomedate` date NOT NULL,
  `incomesource` varchar(50) NOT NULL,
  `description` text,
  PRIMARY KEY (`income_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Income source categories
CREATE TABLE IF NOT EXISTS `income_categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `income_categories` (`category_name`) VALUES
('Salary'),
('Freelance'),
('Business'),
('Investment'),
('Rental'),
('Other');

-- Trigger to update balance when income is added
DELIMITER //
CREATE TRIGGER update_balance_after_income
AFTER INSERT ON income
FOR EACH ROW
BEGIN
    UPDATE users 
    SET balance = balance + NEW.amount 
    WHERE user_id = NEW.user_id;
END//
DELIMITER ;
