-- Personal Expense Tracker Database Setup
-- Import this file in phpMyAdmin

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;

CREATE DATABASE IF NOT EXISTS `dailyexpense`;
USE `dailyexpense`;

DROP TRIGGER IF EXISTS update_balance_after_expense;
DROP TRIGGER IF EXISTS update_balance_after_expense_delete;
DROP TRIGGER IF EXISTS update_balance_after_income;
DROP TRIGGER IF EXISTS update_balance_after_income_delete;

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(25) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `balance` DECIMAL(12,2) NOT NULL DEFAULT 0,
  `profile_path` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `expense_categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `income_categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `expenses` (
  `expense_id` int(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `expense` DECIMAL(12,2) NOT NULL,
  `expensedate` date NOT NULL,
  `expensecategory` varchar(50) NOT NULL,
  PRIMARY KEY (`expense_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `income` (
  `income_id` int(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `amount` DECIMAL(12,2) NOT NULL,
  `incomedate` date NOT NULL,
  `incomesource` varchar(50) NOT NULL,
  `description` text,
  PRIMARY KEY (`income_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO `expense_categories` (`category_name`) VALUES
('Medicine'),('Food'),('Bills & Recharges'),('Entertainment'),
('Clothings'),('Rent'),('Household Items'),('Others');

INSERT IGNORE INTO `income_categories` (`category_name`) VALUES
('Salary'),('Freelance'),('Business'),('Investment'),('Rental'),('Other');

DELIMITER //
CREATE TRIGGER update_balance_after_expense AFTER INSERT ON expenses
FOR EACH ROW BEGIN UPDATE users SET balance = balance - NEW.expense WHERE user_id = NEW.user_id; END//

CREATE TRIGGER update_balance_after_expense_delete AFTER DELETE ON expenses
FOR EACH ROW BEGIN UPDATE users SET balance = balance + OLD.expense WHERE user_id = OLD.user_id; END//

CREATE TRIGGER update_balance_after_income AFTER INSERT ON income
FOR EACH ROW BEGIN UPDATE users SET balance = balance + NEW.amount WHERE user_id = NEW.user_id; END//

CREATE TRIGGER update_balance_after_income_delete AFTER DELETE ON income
FOR EACH ROW BEGIN UPDATE users SET balance = balance - OLD.amount WHERE user_id = OLD.user_id; END//
DELIMITER ;

COMMIT;
