-- Database setup for Personal Expense Tracker
-- This file contains all necessary SQL queries to set up the database in XAMPP

-- Set SQL mode and timezone
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- Create database if not exists
CREATE DATABASE IF NOT EXISTS `dailyexpense` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `dailyexpense`;

-- --------------------------------------------------------
-- Table structure for table `users`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(25) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `balance` DECIMAL(12,2) NOT NULL DEFAULT 0,
  `profile_path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `expense_categories`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `expense_categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `expenses`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `expenses` (
  `expense_id` int(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `expense` DECIMAL(12,2) NOT NULL,
  `expensedate` date NOT NULL,
  `expensecategory` varchar(50) NOT NULL,
  PRIMARY KEY (`expense_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `expenses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `income_categories`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `income_categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `income`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `income` (
  `income_id` int(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `amount` DECIMAL(12,2) NOT NULL,
  `incomedate` date NOT NULL,
  `incomesource` varchar(50) NOT NULL,
  `description` text,
  PRIMARY KEY (`income_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `income_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Insert initial data for expense categories
-- --------------------------------------------------------
INSERT INTO `expense_categories` (`category_name`) VALUES
('Medicine'),
('Food'),
('Bills & Recharges'),
('Entertainment'),
('Clothings'),
('Rent'),
('Household Items'),
('Others');

-- --------------------------------------------------------
-- Insert initial data for income categories
-- --------------------------------------------------------
INSERT INTO `income_categories` (`category_name`) VALUES
('Salary'),
('Freelance'),
('Business'),
('Investment'),
('Rental'),
('Other');

-- --------------------------------------------------------
-- Create triggers for balance management
-- --------------------------------------------------------
DELIMITER //

-- Trigger to update balance when expense is added
CREATE TRIGGER update_balance_after_expense
AFTER INSERT ON expenses
FOR EACH ROW
BEGIN
    UPDATE users 
    SET balance = COALESCE(balance, 0) - NEW.expense 
    WHERE user_id = NEW.user_id;
END//

-- Trigger to update balance when expense is deleted
CREATE TRIGGER update_balance_after_expense_delete
AFTER DELETE ON expenses
FOR EACH ROW
BEGIN
    UPDATE users 
    SET balance = COALESCE(balance, 0) + OLD.expense 
    WHERE user_id = OLD.user_id;
END//

-- Trigger to update balance when income is added
CREATE TRIGGER update_balance_after_income
AFTER INSERT ON income
FOR EACH ROW
BEGIN
    UPDATE users 
    SET balance = COALESCE(balance, 0) + NEW.amount 
    WHERE user_id = NEW.user_id;
END//

-- Trigger to update balance when income is deleted
CREATE TRIGGER update_balance_after_income_delete
AFTER DELETE ON income
FOR EACH ROW
BEGIN
    UPDATE users 
    SET balance = COALESCE(balance, 0) - OLD.amount 
    WHERE user_id = OLD.user_id;
END//

DELIMITER ;

-- --------------------------------------------------------
-- Insert a default user for testing
-- --------------------------------------------------------
INSERT INTO `users` (`firstname`, `lastname`, `email`, `password`, `balance`) VALUES
('Anjalita', 'Fernandes', 'anjalita@sjec.in', 'b7161ae9080c2604adb157463312ed47', 0);

COMMIT; 