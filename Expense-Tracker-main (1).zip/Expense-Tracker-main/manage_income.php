<?php
include("session.php");
$successMessage = "";
$errorMessage = "";

// Delete income record
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    
    // First, get the amount to subtract from balance
    $getAmount = "SELECT amount FROM income WHERE income_id = $id AND user_id = '$userid'";
    $amountResult = $con->query($getAmount);
    if ($amountResult->num_rows > 0) {
        $row = $amountResult->fetch_assoc();
        $amount = $row['amount'];
        
        // Update user balance
        $updateBalance = "UPDATE users SET balance = balance - $amount WHERE user_id = '$userid'";
        $con->query($updateBalance);
        
        // Delete the income record
        $deleteSql = "DELETE FROM income WHERE income_id = $id AND user_id = '$userid'";
        if ($con->query($deleteSql) === TRUE) {
            $successMessage = "Income record deleted successfully!";
        } else {
            $errorMessage = "Error deleting record: " . $con->error;
        }
    }
}

// Fetch income records
$sql = "SELECT * FROM income WHERE user_id = '$userid' ORDER BY incomedate DESC";
$result = $con->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Manage Income - Expense Manager</title>
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <script src="js/feather.min.js"></script>
</head>

<body>
    <div class="d-flex" id="wrapper">
        <!-- Sidebar -->
        <div class="border-right" id="sidebar-wrapper">
            <div class="user">
                <img class="img img-fluid rounded-circle" src="uploads/default_profile.png" width="120">
                <h5><?php echo $username ?></h5>
                <p><?php echo $useremail ?></p>
                <p><strong>Balance:</strong> ₹<?php echo number_format($userbalance, 2); ?></p>
            </div>
            <div class="sidebar-heading">Management</div>
            <div class="list-group list-group-flush">
                <a href="index.php" class="list-group-item list-group-item-action"><span data-feather="home"></span> Dashboard</a>
                <a href="add_income.php" class="list-group-item list-group-item-action"><span data-feather="plus-circle"></span> Add Income</a>
                <a href="manage_income.php" class="list-group-item list-group-item-action sidebar-active"><span data-feather="dollar-sign"></span> Manage Income</a>
                <a href="add_expense.php" class="list-group-item list-group-item-action"><span data-feather="plus-square"></span> Add Expenses</a>
                <a href="manage_expense.php" class="list-group-item list-group-item-action"><span data-feather="dollar-sign"></span> Manage Expenses</a>
                <a href="expensereport.php" class="list-group-item list-group-item-action"><span data-feather="file-text"></span> Expense Report</a>
            </div>
            <div class="sidebar-heading">Settings </div>
            <div class="list-group list-group-flush">
                <a href="profile.php" class="list-group-item list-group-item-action"><span data-feather="user"></span> Profile</a>
                <a href="logout.php" class="list-group-item list-group-item-action"><span data-feather="power"></span> Logout</a>
            </div>
        </div>

        <!-- Page Content -->
        <div id="page-content-wrapper">
            <nav class="navbar navbar-expand-lg navbar-light border-bottom">
                <button class="toggler" type="button" id="menu-toggle" aria-expanded="false">
                    <span data-feather="menu"></span>
                </button>
            </nav>

            <div class="container-fluid">
                <h3 class="mt-4 text-center">Manage Income</h3>
                <?php if ($successMessage): ?>
                    <div class="alert alert-success" role="alert"><?php echo $successMessage; ?></div>
                <?php endif; ?>
                <?php if ($errorMessage): ?>
                    <div class="alert alert-danger" role="alert"><?php echo $errorMessage; ?></div>
                <?php endif; ?>
                
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Amount</th>
                                <th>Source</th>
                                <th>Description</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($result->num_rows > 0) {
                                while($row = $result->fetch_assoc()) {
                                    echo "<tr>";
                                    echo "<td>" . date('Y-m-d', strtotime($row['incomedate'])) . "</td>";
                                    echo "<td>₹" . number_format($row['amount'], 2) . "</td>";
                                    echo "<td>" . $row['incomesource'] . "</td>";
                                    echo "<td>" . $row['description'] . "</td>";
                                    echo "<td>
                                            <a href='manage_income.php?delete=" . $row['income_id'] . "' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                                          </td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='5' class='text-center'>No income records found</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="js/jquery.slim.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script>
        feather.replace();
        $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#wrapper").toggleClass("toggled");
        });
    </script>
</body>
</html>
