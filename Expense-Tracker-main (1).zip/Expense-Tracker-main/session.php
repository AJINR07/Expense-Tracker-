<?php
include("config.php");
session_start();
if(!isset($_SESSION["email"])){
    header("Location: login.php");
    exit();
}

$sess_email = $_SESSION["email"];
$sql = "SELECT * FROM users WHERE email = '$sess_email'";
$result = $con->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $userid = $row["user_id"];
        $firstname = $row["firstname"];
        $lastname = $row["lastname"];
        $username = $row["firstname"]." ".$row["lastname"];
        $useremail = $row["email"];
        $userbalance = isset($row["balance"]) ? $row["balance"] : 0;
        $profile_path = isset($row["profile_path"]) ? $row["profile_path"] : 'default_profile.png';
        $userphone = isset($row["phone"]) ? $row["phone"] : '';
        $useraddress = isset($row["address"]) ? $row["address"] : '';
        $userbio = isset($row["bio"]) ? $row["bio"] : '';
    }
} else {
    $userid = "798";
    $username = "SJEC";
    $useremail = "mailid@domain.com"; 
    $userbalance = 0;
    $profile_path = 'default_profile.png';
    $userphone = '';
    $useraddress = '';
    $userbio = '';
}

function getProfileImage($path) {
    if (empty($path) || $path == 'default_profile.png') {
        return 'uploads/default_profile.png';
    }
    return 'uploads/' . $path;
}
?>
