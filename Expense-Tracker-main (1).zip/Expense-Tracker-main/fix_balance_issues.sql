-- =============================================
-- Database Balance Fix Script
-- Purpose: Fix and maintain user balance consistency
-- =============================================

-- Step 1: Ensure proper table structure
-- =============================================
-- Modify column types to ensure consistency with users table
ALTER TABLE expenses MODIFY COLUMN user_id int(11) NOT NULL;
ALTER TABLE income MODIFY COLUMN user_id int(11) NOT NULL;

-- Step 2: Clean up existing triggers
-- =============================================
-- Remove any existing triggers to avoid conflicts
DROP TRIGGER IF EXISTS update_balance_after_expense;
DROP TRIGGER IF EXISTS update_balance_after_expense_delete;
DROP TRIGGER IF EXISTS update_balance_after_income;
DROP TRIGGER IF EXISTS update_balance_after_income_delete;

-- Step 3: Create new triggers
-- =============================================
DELIMITER //

-- Trigger for new expense entries
CREATE TRIGGER update_balance_after_expense
AFTER INSERT ON expenses
FOR EACH ROW
BEGIN
    UPDATE users 
    SET balance = COALESCE(balance, 0) - NEW.expense 
    WHERE user_id = NEW.user_id;
END//

-- Trigger for deleted expense entries
CREATE TRIGGER update_balance_after_expense_delete
AFTER DELETE ON expenses
FOR EACH ROW
BEGIN
    UPDATE users 
    SET balance = COALESCE(balance, 0) + OLD.expense 
    WHERE user_id = OLD.user_id;
END//

-- Trigger for new income entries
CREATE TRIGGER update_balance_after_income
AFTER INSERT ON income
FOR EACH ROW
BEGIN
    UPDATE users 
    SET balance = COALESCE(balance, 0) + NEW.amount 
    WHERE user_id = NEW.user_id;
END//

-- Trigger for deleted income entries
CREATE TRIGGER update_balance_after_income_delete
AFTER DELETE ON income
FOR EACH ROW
BEGIN
    UPDATE users 
    SET balance = COALESCE(balance, 0) - OLD.amount 
    WHERE user_id = OLD.user_id;
END//

DELIMITER ;

-- Step 4: Data cleanup
-- =============================================
-- Initialize any NULL balances to 0
UPDATE users SET balance = 0 WHERE balance IS NULL;

-- Step 5: Verification query (optional)
-- =============================================
-- Uncomment the following line to verify the changes:
-- SELECT user_id, balance FROM users ORDER BY user_id;
